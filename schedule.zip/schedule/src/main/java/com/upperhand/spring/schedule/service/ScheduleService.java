package com.upperhand.spring.schedule.service;

import com.upperhand.spring.schedule.dao.ScheduleEntity;

public interface ScheduleService {

	void enroll(ScheduleEntity scheduleEntity);

}
